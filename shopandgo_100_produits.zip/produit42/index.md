---
layout: default
title: Produit 42
---

# Produit 42

Ceci est la page détaillée du produit 42.
