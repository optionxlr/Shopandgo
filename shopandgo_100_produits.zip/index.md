---
layout: none
---

<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8">
  <title>Shopandgo</title>
  <style>
    body {
      margin: 0;
      padding: 0;
      background-color: #4B0000;
      font-family: 'Segoe UI', sans-serif;
      color: white;
    }

    .container {
      max-width: 1200px;
      margin: 40px auto;
      display: grid;
      grid-template-columns: repeat(4, 1fr);
      gap: 30px;
    }

    .product {
      background-color: #5e0000;
      padding: 10px;
      border-radius: 12px;
      box-shadow: 0 0 15px #00000088;
      transition: transform 0.3s ease;
    }

    .product:hover {
      transform: scale(1.03);
    }

    .product img {
      width: 100%;
      border-radius: 10px;
    }

    .description {
      margin-top: 10px;
      font-size: 14px;
      text-align: center;
    }

    .neon-bar {
      height: 5px;
      background: #00faff;
      box-shadow: 0 0 12px #00faff, 0 0 24px #00faff;
      margin-top: 8px;
      border-radius: 3px;
    }

    a {
      text-decoration: none;
      color: inherit;
    }
  </style>
</head>
<body>
  <h1 style="text-align:center; padding: 30px;">Bienvenue sur Shopandgo</h1>

  <div class="container">

    <div class="product">
      <a href="/produit1/">
        <div class="description">Produit 1 - Titre simple</div>
        <img src="https://via.placeholder.com/300x200?text=Produit+1" alt="Produit 1">
        <div class="neon-bar"></div>
      </a>
    </div>

    <div class="product">
      <a href="/produit2/">
        <div class="description">Produit 2 - Titre simple</div>
        <img src="https://via.placeholder.com/300x200?text=Produit+2" alt="Produit 2">
        <div class="neon-bar"></div>
      </a>
    </div>

    <div class="product">
      <a href="/produit3/">
        <div class="description">Produit 3 - Titre simple</div>
        <img src="https://via.placeholder.com/300x200?text=Produit+3" alt="Produit 3">
        <div class="neon-bar"></div>
      </a>
    </div>

    <div class="product">
      <a href="/produit4/">
        <div class="description">Produit 4 - Titre simple</div>
        <img src="https://via.placeholder.com/300x200?text=Produit+4" alt="Produit 4">
        <div class="neon-bar"></div>
      </a>
    </div>

    <div class="product">
      <a href="/produit5/">
        <div class="description">Produit 5 - Titre simple</div>
        <img src="https://via.placeholder.com/300x200?text=Produit+5" alt="Produit 5">
        <div class="neon-bar"></div>
      </a>
    </div>

    <div class="product">
      <a href="/produit6/">
        <div class="description">Produit 6 - Titre simple</div>
        <img src="https://via.placeholder.com/300x200?text=Produit+6" alt="Produit 6">
        <div class="neon-bar"></div>
      </a>
    </div>

    <div class="product">
      <a href="/produit7/">
        <div class="description">Produit 7 - Titre simple</div>
        <img src="https://via.placeholder.com/300x200?text=Produit+7" alt="Produit 7">
        <div class="neon-bar"></div>
      </a>
    </div>

    <div class="product">
      <a href="/produit8/">
        <div class="description">Produit 8 - Titre simple</div>
        <img src="https://via.placeholder.com/300x200?text=Produit+8" alt="Produit 8">
        <div class="neon-bar"></div>
      </a>
    </div>

    <div class="product">
      <a href="/produit9/">
        <div class="description">Produit 9 - Titre simple</div>
        <img src="https://via.placeholder.com/300x200?text=Produit+9" alt="Produit 9">
        <div class="neon-bar"></div>
      </a>
    </div>

    <div class="product">
      <a href="/produit10/">
        <div class="description">Produit 10 - Titre simple</div>
        <img src="https://via.placeholder.com/300x200?text=Produit+10" alt="Produit 10">
        <div class="neon-bar"></div>
      </a>
    </div>

    <div class="product">
      <a href="/produit11/">
        <div class="description">Produit 11 - Titre simple</div>
        <img src="https://via.placeholder.com/300x200?text=Produit+11" alt="Produit 11">
        <div class="neon-bar"></div>
      </a>
    </div>

    <div class="product">
      <a href="/produit12/">
        <div class="description">Produit 12 - Titre simple</div>
        <img src="https://via.placeholder.com/300x200?text=Produit+12" alt="Produit 12">
        <div class="neon-bar"></div>
      </a>
    </div>

    <div class="product">
      <a href="/produit13/">
        <div class="description">Produit 13 - Titre simple</div>
        <img src="https://via.placeholder.com/300x200?text=Produit+13" alt="Produit 13">
        <div class="neon-bar"></div>
      </a>
    </div>

    <div class="product">
      <a href="/produit14/">
        <div class="description">Produit 14 - Titre simple</div>
        <img src="https://via.placeholder.com/300x200?text=Produit+14" alt="Produit 14">
        <div class="neon-bar"></div>
      </a>
    </div>

    <div class="product">
      <a href="/produit15/">
        <div class="description">Produit 15 - Titre simple</div>
        <img src="https://via.placeholder.com/300x200?text=Produit+15" alt="Produit 15">
        <div class="neon-bar"></div>
      </a>
    </div>

    <div class="product">
      <a href="/produit16/">
        <div class="description">Produit 16 - Titre simple</div>
        <img src="https://via.placeholder.com/300x200?text=Produit+16" alt="Produit 16">
        <div class="neon-bar"></div>
      </a>
    </div>

    <div class="product">
      <a href="/produit17/">
        <div class="description">Produit 17 - Titre simple</div>
        <img src="https://via.placeholder.com/300x200?text=Produit+17" alt="Produit 17">
        <div class="neon-bar"></div>
      </a>
    </div>

    <div class="product">
      <a href="/produit18/">
        <div class="description">Produit 18 - Titre simple</div>
        <img src="https://via.placeholder.com/300x200?text=Produit+18" alt="Produit 18">
        <div class="neon-bar"></div>
      </a>
    </div>

    <div class="product">
      <a href="/produit19/">
        <div class="description">Produit 19 - Titre simple</div>
        <img src="https://via.placeholder.com/300x200?text=Produit+19" alt="Produit 19">
        <div class="neon-bar"></div>
      </a>
    </div>

    <div class="product">
      <a href="/produit20/">
        <div class="description">Produit 20 - Titre simple</div>
        <img src="https://via.placeholder.com/300x200?text=Produit+20" alt="Produit 20">
        <div class="neon-bar"></div>
      </a>
    </div>

    <div class="product">
      <a href="/produit21/">
        <div class="description">Produit 21 - Titre simple</div>
        <img src="https://via.placeholder.com/300x200?text=Produit+21" alt="Produit 21">
        <div class="neon-bar"></div>
      </a>
    </div>

    <div class="product">
      <a href="/produit22/">
        <div class="description">Produit 22 - Titre simple</div>
        <img src="https://via.placeholder.com/300x200?text=Produit+22" alt="Produit 22">
        <div class="neon-bar"></div>
      </a>
    </div>

    <div class="product">
      <a href="/produit23/">
        <div class="description">Produit 23 - Titre simple</div>
        <img src="https://via.placeholder.com/300x200?text=Produit+23" alt="Produit 23">
        <div class="neon-bar"></div>
      </a>
    </div>

    <div class="product">
      <a href="/produit24/">
        <div class="description">Produit 24 - Titre simple</div>
        <img src="https://via.placeholder.com/300x200?text=Produit+24" alt="Produit 24">
        <div class="neon-bar"></div>
      </a>
    </div>

    <div class="product">
      <a href="/produit25/">
        <div class="description">Produit 25 - Titre simple</div>
        <img src="https://via.placeholder.com/300x200?text=Produit+25" alt="Produit 25">
        <div class="neon-bar"></div>
      </a>
    </div>

    <div class="product">
      <a href="/produit26/">
        <div class="description">Produit 26 - Titre simple</div>
        <img src="https://via.placeholder.com/300x200?text=Produit+26" alt="Produit 26">
        <div class="neon-bar"></div>
      </a>
    </div>

    <div class="product">
      <a href="/produit27/">
        <div class="description">Produit 27 - Titre simple</div>
        <img src="https://via.placeholder.com/300x200?text=Produit+27" alt="Produit 27">
        <div class="neon-bar"></div>
      </a>
    </div>

    <div class="product">
      <a href="/produit28/">
        <div class="description">Produit 28 - Titre simple</div>
        <img src="https://via.placeholder.com/300x200?text=Produit+28" alt="Produit 28">
        <div class="neon-bar"></div>
      </a>
    </div>

    <div class="product">
      <a href="/produit29/">
        <div class="description">Produit 29 - Titre simple</div>
        <img src="https://via.placeholder.com/300x200?text=Produit+29" alt="Produit 29">
        <div class="neon-bar"></div>
      </a>
    </div>

    <div class="product">
      <a href="/produit30/">
        <div class="description">Produit 30 - Titre simple</div>
        <img src="https://via.placeholder.com/300x200?text=Produit+30" alt="Produit 30">
        <div class="neon-bar"></div>
      </a>
    </div>

    <div class="product">
      <a href="/produit31/">
        <div class="description">Produit 31 - Titre simple</div>
        <img src="https://via.placeholder.com/300x200?text=Produit+31" alt="Produit 31">
        <div class="neon-bar"></div>
      </a>
    </div>

    <div class="product">
      <a href="/produit32/">
        <div class="description">Produit 32 - Titre simple</div>
        <img src="https://via.placeholder.com/300x200?text=Produit+32" alt="Produit 32">
        <div class="neon-bar"></div>
      </a>
    </div>

    <div class="product">
      <a href="/produit33/">
        <div class="description">Produit 33 - Titre simple</div>
        <img src="https://via.placeholder.com/300x200?text=Produit+33" alt="Produit 33">
        <div class="neon-bar"></div>
      </a>
    </div>

    <div class="product">
      <a href="/produit34/">
        <div class="description">Produit 34 - Titre simple</div>
        <img src="https://via.placeholder.com/300x200?text=Produit+34" alt="Produit 34">
        <div class="neon-bar"></div>
      </a>
    </div>

    <div class="product">
      <a href="/produit35/">
        <div class="description">Produit 35 - Titre simple</div>
        <img src="https://via.placeholder.com/300x200?text=Produit+35" alt="Produit 35">
        <div class="neon-bar"></div>
      </a>
    </div>

    <div class="product">
      <a href="/produit36/">
        <div class="description">Produit 36 - Titre simple</div>
        <img src="https://via.placeholder.com/300x200?text=Produit+36" alt="Produit 36">
        <div class="neon-bar"></div>
      </a>
    </div>

    <div class="product">
      <a href="/produit37/">
        <div class="description">Produit 37 - Titre simple</div>
        <img src="https://via.placeholder.com/300x200?text=Produit+37" alt="Produit 37">
        <div class="neon-bar"></div>
      </a>
    </div>

    <div class="product">
      <a href="/produit38/">
        <div class="description">Produit 38 - Titre simple</div>
        <img src="https://via.placeholder.com/300x200?text=Produit+38" alt="Produit 38">
        <div class="neon-bar"></div>
      </a>
    </div>

    <div class="product">
      <a href="/produit39/">
        <div class="description">Produit 39 - Titre simple</div>
        <img src="https://via.placeholder.com/300x200?text=Produit+39" alt="Produit 39">
        <div class="neon-bar"></div>
      </a>
    </div>

    <div class="product">
      <a href="/produit40/">
        <div class="description">Produit 40 - Titre simple</div>
        <img src="https://via.placeholder.com/300x200?text=Produit+40" alt="Produit 40">
        <div class="neon-bar"></div>
      </a>
    </div>

    <div class="product">
      <a href="/produit41/">
        <div class="description">Produit 41 - Titre simple</div>
        <img src="https://via.placeholder.com/300x200?text=Produit+41" alt="Produit 41">
        <div class="neon-bar"></div>
      </a>
    </div>

    <div class="product">
      <a href="/produit42/">
        <div class="description">Produit 42 - Titre simple</div>
        <img src="https://via.placeholder.com/300x200?text=Produit+42" alt="Produit 42">
        <div class="neon-bar"></div>
      </a>
    </div>

    <div class="product">
      <a href="/produit43/">
        <div class="description">Produit 43 - Titre simple</div>
        <img src="https://via.placeholder.com/300x200?text=Produit+43" alt="Produit 43">
        <div class="neon-bar"></div>
      </a>
    </div>

    <div class="product">
      <a href="/produit44/">
        <div class="description">Produit 44 - Titre simple</div>
        <img src="https://via.placeholder.com/300x200?text=Produit+44" alt="Produit 44">
        <div class="neon-bar"></div>
      </a>
    </div>

    <div class="product">
      <a href="/produit45/">
        <div class="description">Produit 45 - Titre simple</div>
        <img src="https://via.placeholder.com/300x200?text=Produit+45" alt="Produit 45">
        <div class="neon-bar"></div>
      </a>
    </div>

    <div class="product">
      <a href="/produit46/">
        <div class="description">Produit 46 - Titre simple</div>
        <img src="https://via.placeholder.com/300x200?text=Produit+46" alt="Produit 46">
        <div class="neon-bar"></div>
      </a>
    </div>

    <div class="product">
      <a href="/produit47/">
        <div class="description">Produit 47 - Titre simple</div>
        <img src="https://via.placeholder.com/300x200?text=Produit+47" alt="Produit 47">
        <div class="neon-bar"></div>
      </a>
    </div>

    <div class="product">
      <a href="/produit48/">
        <div class="description">Produit 48 - Titre simple</div>
        <img src="https://via.placeholder.com/300x200?text=Produit+48" alt="Produit 48">
        <div class="neon-bar"></div>
      </a>
    </div>

    <div class="product">
      <a href="/produit49/">
        <div class="description">Produit 49 - Titre simple</div>
        <img src="https://via.placeholder.com/300x200?text=Produit+49" alt="Produit 49">
        <div class="neon-bar"></div>
      </a>
    </div>

    <div class="product">
      <a href="/produit50/">
        <div class="description">Produit 50 - Titre simple</div>
        <img src="https://via.placeholder.com/300x200?text=Produit+50" alt="Produit 50">
        <div class="neon-bar"></div>
      </a>
    </div>

    <div class="product">
      <a href="/produit51/">
        <div class="description">Produit 51 - Titre simple</div>
        <img src="https://via.placeholder.com/300x200?text=Produit+51" alt="Produit 51">
        <div class="neon-bar"></div>
      </a>
    </div>

    <div class="product">
      <a href="/produit52/">
        <div class="description">Produit 52 - Titre simple</div>
        <img src="https://via.placeholder.com/300x200?text=Produit+52" alt="Produit 52">
        <div class="neon-bar"></div>
      </a>
    </div>

    <div class="product">
      <a href="/produit53/">
        <div class="description">Produit 53 - Titre simple</div>
        <img src="https://via.placeholder.com/300x200?text=Produit+53" alt="Produit 53">
        <div class="neon-bar"></div>
      </a>
    </div>

    <div class="product">
      <a href="/produit54/">
        <div class="description">Produit 54 - Titre simple</div>
        <img src="https://via.placeholder.com/300x200?text=Produit+54" alt="Produit 54">
        <div class="neon-bar"></div>
      </a>
    </div>

    <div class="product">
      <a href="/produit55/">
        <div class="description">Produit 55 - Titre simple</div>
        <img src="https://via.placeholder.com/300x200?text=Produit+55" alt="Produit 55">
        <div class="neon-bar"></div>
      </a>
    </div>

    <div class="product">
      <a href="/produit56/">
        <div class="description">Produit 56 - Titre simple</div>
        <img src="https://via.placeholder.com/300x200?text=Produit+56" alt="Produit 56">
        <div class="neon-bar"></div>
      </a>
    </div>

    <div class="product">
      <a href="/produit57/">
        <div class="description">Produit 57 - Titre simple</div>
        <img src="https://via.placeholder.com/300x200?text=Produit+57" alt="Produit 57">
        <div class="neon-bar"></div>
      </a>
    </div>

    <div class="product">
      <a href="/produit58/">
        <div class="description">Produit 58 - Titre simple</div>
        <img src="https://via.placeholder.com/300x200?text=Produit+58" alt="Produit 58">
        <div class="neon-bar"></div>
      </a>
    </div>

    <div class="product">
      <a href="/produit59/">
        <div class="description">Produit 59 - Titre simple</div>
        <img src="https://via.placeholder.com/300x200?text=Produit+59" alt="Produit 59">
        <div class="neon-bar"></div>
      </a>
    </div>

    <div class="product">
      <a href="/produit60/">
        <div class="description">Produit 60 - Titre simple</div>
        <img src="https://via.placeholder.com/300x200?text=Produit+60" alt="Produit 60">
        <div class="neon-bar"></div>
      </a>
    </div>

    <div class="product">
      <a href="/produit61/">
        <div class="description">Produit 61 - Titre simple</div>
        <img src="https://via.placeholder.com/300x200?text=Produit+61" alt="Produit 61">
        <div class="neon-bar"></div>
      </a>
    </div>

    <div class="product">
      <a href="/produit62/">
        <div class="description">Produit 62 - Titre simple</div>
        <img src="https://via.placeholder.com/300x200?text=Produit+62" alt="Produit 62">
        <div class="neon-bar"></div>
      </a>
    </div>

    <div class="product">
      <a href="/produit63/">
        <div class="description">Produit 63 - Titre simple</div>
        <img src="https://via.placeholder.com/300x200?text=Produit+63" alt="Produit 63">
        <div class="neon-bar"></div>
      </a>
    </div>

    <div class="product">
      <a href="/produit64/">
        <div class="description">Produit 64 - Titre simple</div>
        <img src="https://via.placeholder.com/300x200?text=Produit+64" alt="Produit 64">
        <div class="neon-bar"></div>
      </a>
    </div>

    <div class="product">
      <a href="/produit65/">
        <div class="description">Produit 65 - Titre simple</div>
        <img src="https://via.placeholder.com/300x200?text=Produit+65" alt="Produit 65">
        <div class="neon-bar"></div>
      </a>
    </div>

    <div class="product">
      <a href="/produit66/">
        <div class="description">Produit 66 - Titre simple</div>
        <img src="https://via.placeholder.com/300x200?text=Produit+66" alt="Produit 66">
        <div class="neon-bar"></div>
      </a>
    </div>

    <div class="product">
      <a href="/produit67/">
        <div class="description">Produit 67 - Titre simple</div>
        <img src="https://via.placeholder.com/300x200?text=Produit+67" alt="Produit 67">
        <div class="neon-bar"></div>
      </a>
    </div>

    <div class="product">
      <a href="/produit68/">
        <div class="description">Produit 68 - Titre simple</div>
        <img src="https://via.placeholder.com/300x200?text=Produit+68" alt="Produit 68">
        <div class="neon-bar"></div>
      </a>
    </div>

    <div class="product">
      <a href="/produit69/">
        <div class="description">Produit 69 - Titre simple</div>
        <img src="https://via.placeholder.com/300x200?text=Produit+69" alt="Produit 69">
        <div class="neon-bar"></div>
      </a>
    </div>

    <div class="product">
      <a href="/produit70/">
        <div class="description">Produit 70 - Titre simple</div>
        <img src="https://via.placeholder.com/300x200?text=Produit+70" alt="Produit 70">
        <div class="neon-bar"></div>
      </a>
    </div>

    <div class="product">
      <a href="/produit71/">
        <div class="description">Produit 71 - Titre simple</div>
        <img src="https://via.placeholder.com/300x200?text=Produit+71" alt="Produit 71">
        <div class="neon-bar"></div>
      </a>
    </div>

    <div class="product">
      <a href="/produit72/">
        <div class="description">Produit 72 - Titre simple</div>
        <img src="https://via.placeholder.com/300x200?text=Produit+72" alt="Produit 72">
        <div class="neon-bar"></div>
      </a>
    </div>

    <div class="product">
      <a href="/produit73/">
        <div class="description">Produit 73 - Titre simple</div>
        <img src="https://via.placeholder.com/300x200?text=Produit+73" alt="Produit 73">
        <div class="neon-bar"></div>
      </a>
    </div>

    <div class="product">
      <a href="/produit74/">
        <div class="description">Produit 74 - Titre simple</div>
        <img src="https://via.placeholder.com/300x200?text=Produit+74" alt="Produit 74">
        <div class="neon-bar"></div>
      </a>
    </div>

    <div class="product">
      <a href="/produit75/">
        <div class="description">Produit 75 - Titre simple</div>
        <img src="https://via.placeholder.com/300x200?text=Produit+75" alt="Produit 75">
        <div class="neon-bar"></div>
      </a>
    </div>

    <div class="product">
      <a href="/produit76/">
        <div class="description">Produit 76 - Titre simple</div>
        <img src="https://via.placeholder.com/300x200?text=Produit+76" alt="Produit 76">
        <div class="neon-bar"></div>
      </a>
    </div>

    <div class="product">
      <a href="/produit77/">
        <div class="description">Produit 77 - Titre simple</div>
        <img src="https://via.placeholder.com/300x200?text=Produit+77" alt="Produit 77">
        <div class="neon-bar"></div>
      </a>
    </div>

    <div class="product">
      <a href="/produit78/">
        <div class="description">Produit 78 - Titre simple</div>
        <img src="https://via.placeholder.com/300x200?text=Produit+78" alt="Produit 78">
        <div class="neon-bar"></div>
      </a>
    </div>

    <div class="product">
      <a href="/produit79/">
        <div class="description">Produit 79 - Titre simple</div>
        <img src="https://via.placeholder.com/300x200?text=Produit+79" alt="Produit 79">
        <div class="neon-bar"></div>
      </a>
    </div>

    <div class="product">
      <a href="/produit80/">
        <div class="description">Produit 80 - Titre simple</div>
        <img src="https://via.placeholder.com/300x200?text=Produit+80" alt="Produit 80">
        <div class="neon-bar"></div>
      </a>
    </div>

    <div class="product">
      <a href="/produit81/">
        <div class="description">Produit 81 - Titre simple</div>
        <img src="https://via.placeholder.com/300x200?text=Produit+81" alt="Produit 81">
        <div class="neon-bar"></div>
      </a>
    </div>

    <div class="product">
      <a href="/produit82/">
        <div class="description">Produit 82 - Titre simple</div>
        <img src="https://via.placeholder.com/300x200?text=Produit+82" alt="Produit 82">
        <div class="neon-bar"></div>
      </a>
    </div>

    <div class="product">
      <a href="/produit83/">
        <div class="description">Produit 83 - Titre simple</div>
        <img src="https://via.placeholder.com/300x200?text=Produit+83" alt="Produit 83">
        <div class="neon-bar"></div>
      </a>
    </div>

    <div class="product">
      <a href="/produit84/">
        <div class="description">Produit 84 - Titre simple</div>
        <img src="https://via.placeholder.com/300x200?text=Produit+84" alt="Produit 84">
        <div class="neon-bar"></div>
      </a>
    </div>

    <div class="product">
      <a href="/produit85/">
        <div class="description">Produit 85 - Titre simple</div>
        <img src="https://via.placeholder.com/300x200?text=Produit+85" alt="Produit 85">
        <div class="neon-bar"></div>
      </a>
    </div>

    <div class="product">
      <a href="/produit86/">
        <div class="description">Produit 86 - Titre simple</div>
        <img src="https://via.placeholder.com/300x200?text=Produit+86" alt="Produit 86">
        <div class="neon-bar"></div>
      </a>
    </div>

    <div class="product">
      <a href="/produit87/">
        <div class="description">Produit 87 - Titre simple</div>
        <img src="https://via.placeholder.com/300x200?text=Produit+87" alt="Produit 87">
        <div class="neon-bar"></div>
      </a>
    </div>

    <div class="product">
      <a href="/produit88/">
        <div class="description">Produit 88 - Titre simple</div>
        <img src="https://via.placeholder.com/300x200?text=Produit+88" alt="Produit 88">
        <div class="neon-bar"></div>
      </a>
    </div>

    <div class="product">
      <a href="/produit89/">
        <div class="description">Produit 89 - Titre simple</div>
        <img src="https://via.placeholder.com/300x200?text=Produit+89" alt="Produit 89">
        <div class="neon-bar"></div>
      </a>
    </div>

    <div class="product">
      <a href="/produit90/">
        <div class="description">Produit 90 - Titre simple</div>
        <img src="https://via.placeholder.com/300x200?text=Produit+90" alt="Produit 90">
        <div class="neon-bar"></div>
      </a>
    </div>

    <div class="product">
      <a href="/produit91/">
        <div class="description">Produit 91 - Titre simple</div>
        <img src="https://via.placeholder.com/300x200?text=Produit+91" alt="Produit 91">
        <div class="neon-bar"></div>
      </a>
    </div>

    <div class="product">
      <a href="/produit92/">
        <div class="description">Produit 92 - Titre simple</div>
        <img src="https://via.placeholder.com/300x200?text=Produit+92" alt="Produit 92">
        <div class="neon-bar"></div>
      </a>
    </div>

    <div class="product">
      <a href="/produit93/">
        <div class="description">Produit 93 - Titre simple</div>
        <img src="https://via.placeholder.com/300x200?text=Produit+93" alt="Produit 93">
        <div class="neon-bar"></div>
      </a>
    </div>

    <div class="product">
      <a href="/produit94/">
        <div class="description">Produit 94 - Titre simple</div>
        <img src="https://via.placeholder.com/300x200?text=Produit+94" alt="Produit 94">
        <div class="neon-bar"></div>
      </a>
    </div>

    <div class="product">
      <a href="/produit95/">
        <div class="description">Produit 95 - Titre simple</div>
        <img src="https://via.placeholder.com/300x200?text=Produit+95" alt="Produit 95">
        <div class="neon-bar"></div>
      </a>
    </div>

    <div class="product">
      <a href="/produit96/">
        <div class="description">Produit 96 - Titre simple</div>
        <img src="https://via.placeholder.com/300x200?text=Produit+96" alt="Produit 96">
        <div class="neon-bar"></div>
      </a>
    </div>

    <div class="product">
      <a href="/produit97/">
        <div class="description">Produit 97 - Titre simple</div>
        <img src="https://via.placeholder.com/300x200?text=Produit+97" alt="Produit 97">
        <div class="neon-bar"></div>
      </a>
    </div>

    <div class="product">
      <a href="/produit98/">
        <div class="description">Produit 98 - Titre simple</div>
        <img src="https://via.placeholder.com/300x200?text=Produit+98" alt="Produit 98">
        <div class="neon-bar"></div>
      </a>
    </div>

    <div class="product">
      <a href="/produit99/">
        <div class="description">Produit 99 - Titre simple</div>
        <img src="https://via.placeholder.com/300x200?text=Produit+99" alt="Produit 99">
        <div class="neon-bar"></div>
      </a>
    </div>

    <div class="product">
      <a href="/produit100/">
        <div class="description">Produit 100 - Titre simple</div>
        <img src="https://via.placeholder.com/300x200?text=Produit+100" alt="Produit 100">
        <div class="neon-bar"></div>
      </a>
    </div>

  </div>
</body>
</html>
